<?php 

$conn = new mysqli('localhost','root','','vue_user');

$data =  json_decode(file_get_contents('php://input'));

$action = "read";
if( isset($_GET['action']) ){
    $action = $_GET['action'];
}

/**
 * Get all user data
 */
if($action == 'read'){
    $dat = $conn -> query("SELECT * FROM user ORDER By id DESC");
    $all_users = [];
    while( $user = $dat -> fetch_assoc() ){
        array_push($all_users, $user);
    }
    echo json_encode($all_users);
}

/**
 * Add New Data
 */
if($action == 'create'){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $location = $_POST['location'];

  $file_name =  $_FILES['photo']['name'];
  $file_tmp_name =  $_FILES['photo']['tmp_name'];

  move_uploaded_file($file_tmp_name, '../photo/user/'.$file_name );

//      = $data -> name;
//      $data -> email;
//     $data -> age;
//     $data -> gender;
//     $data -> location;


$dat = $conn -> query("INSERT INTO user (name, email, age, gender, location, photo) VALUES('$name','$email','$age','$gender','$location','$file_name')");

}

/**
 * Edit user
 */
if($action == 'edit'){

    $id = $_GET['id'];

     
   $dat = $conn -> query("SELECT * FROM user WHERE id ='$id'");
  
   $single_user = $dat -> fetch_assoc();
 
 echo  json_encode( $single_user);

}

/**
 * Update user
 */
if($action == 'update'){

    echo $id =  $_GET['id'];

   $name = $_POST['name'];
   $email = $_POST['email'];
   $age = $_POST['age'];
   $gender = $_POST['gender'];
   $location = $_POST['location'];

   $photo_name =  $_FILES['photo']['name'];
   $photo_tmp_name =  $_FILES['photo']['tmp_name'];

   
  move_uploaded_file($photo_tmp_name, '../photo/user/'.$photo_name );

   $dat = $conn -> query("UPDATE  user SET name='$name', email='$email', age='$age', gender='$gender', location='$location', photo='$photo_name' WHERE id ='$id'");
  


}

/**
 * Delete user
 */
if($action == 'delete'){

    $id = $_GET['id'];

    $conn = new mysqli('localhost','root','','vue_user');
    
    $dat = $conn -> query("DELETE FROM user WHERE id='$id'");
    
}


/**
 * Search User
 */
if($action == 'search'){

    $search = $_GET['s'];
 
    $conn = new mysqli('localhost','root','','vue_user');
     
    $dat = $conn -> query("SELECT * FROM user WHERE name LIKE '%$search%' ");
   
    $searchResult = [];
    while( $search = $dat -> fetch_assoc() ){
     array_push($searchResult, $search);
     }
     echo json_encode($searchResult);
 }

 
/**
 * Search User with gender
 */
if($action == 'malesearch'){
     $gnder = $_GET['ss'];
    
    $dat = $conn -> query("SELECT * FROM user WHERE gender LIKE '$gnder' ");
        $all_data = [];
    while( $data = $dat -> fetch_assoc() ){
        // print_r($data);
        array_push($all_data, $data);
    }
      echo json_encode($all_data);

   }


   if($action == 'femalesearch'){
     $gnderf = $_GET['sfs'];

    $dat = $conn -> query("SELECT * FROM user WHERE gender LIKE '$gnderf' ");

        $all_female = [];
        while( $femaledata = $dat -> fetch_assoc() ){
            array_push($all_female, $femaledata);

        }
        echo json_encode($all_female);
  
   }


   if($action == 'alluser'){
       
    $dat = $conn -> query("SELECT * FROM user ORDER By id DESC");
    $all_users = [];
    while( $user = $dat -> fetch_assoc() ){
        array_push($all_users, $user);
    }
    echo json_encode($all_users);

 
  }

  if($action == 'location'){

    $location = $_GET['loc'];
       
    $dat = $conn -> query("SELECT * FROM user WHERE location LIKE '$location' ");

    $all_location = [];
    while( $loc = $dat -> fetch_assoc() ){
        array_push($all_location, $loc);
    }
    echo json_encode($all_location);


 
  }



 
 /**
 * single User view action
 */
if($action == 'single'){

     $id = $_GET['id'];

      
    $dat = $conn -> query("SELECT * FROM user WHERE id ='$id'");
   
    $single_user = $dat -> fetch_assoc();
  
  echo  json_encode( $single_user);

 }


 
 


