<?php
$id = $_GET['id'];

$conn = new mysqli('localhost','root','','vue_user');

$dat = $conn -> query("DELETE FROM user WHERE id='$id'");
